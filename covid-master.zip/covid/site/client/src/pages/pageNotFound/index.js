//core
import React from 'react'

export default function PageNotFound() {
    return (
        <h1>Page Not Found</h1>
    )
}
