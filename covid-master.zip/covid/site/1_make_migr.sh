#!/bin/bash

python3 manage.py makemigrations